﻿INSERT INTO `persons` (`FirstName`, `LastName`, `Address`, `Gender`) VALUES
	('Leandro', 'Costa', 'Uberlândia - Minas Gerais - Brasil', 'Male'),
	('Flávio', 'Costa', 'Patos de Minas - Minas Gerais - Brasil', 'Male');
